<?php

session_start();

header("Content-type:text/html; charset=UTF-8");  //UTF-8，如果您的ECSHOP是GBK版本，请将UTF-8改为GBK，同时将该文件另存为ASCII格式

$username = "用户名";  //填写您在美联软通的用户名
$password = "密码";    //填写您在美联软通的密码 
$apikey = "APIKEY";    //填写您在美联软通的APIKEY，请登陆m.5c.com.cn，点击：帐号管理--》我的信息 中查看APIKEY

if($_GET['act']=='send'){
	$yzm = random(4,1);  //生成4位的随机验证码
}
$content = "您的验证码是：".$yzm."【美联软通】";       //短信内容，注册，必须使用签名。该签名可自定义，正式发送时请联系商务为您绑定。





$mobile = $_POST['mobile'];           //用户输入的手机号码，勿改
$mobile_code = $_POST['mobile_code']; //用户输入的短信认证码，勿改

if($_GET['act']=='check'){
	if($mobile!=$_SESSION['mobile'] or $mobile_code!=$_SESSION['mobile_code']){
		exit(json_encode(array('msg'=>'手机验证码输入错误。')));	
	}else{
		exit(json_encode(array('code'=>'2')));	
	}
}

if($_GET['act']=='send'){
	if(empty($mobile)){
		exit(json_encode(array('msg'=>'手机号码不能为空')));
	}
	
	$preg='/^1[0-9]{10}$/';//简单的方法
	if(!preg_match($preg,$mobile)) {
		exit(json_encode(array('msg'=>'手机号码格式不正确')));
	 }	
	
	$mobile_code = $yzm;
	$target = "http://m.5c.com.cn/api/send/index.php";
	//替换成自己的测试账号,参数顺序和wenservice对应

	//exit(json_encode(array('msg'=>strtotime( read_file($mobile))."\r\n".(time()-60) )));
	if($_SESSION['mobile']){
		//exit(json_encode(array('msg'=> read_file($mobile) )));
		if(strtotime(read_file($mobile))>(time()-60)){   //设置60秒只能获取一次
			exit(json_encode(array('msg'=>'获取验证码太过频繁，一分钟之内只能获取一次。')));	
		}
	}
	
	$post_data = "username=".$username."&password=".$password."&apikey=".$apikey."&mobile=".$mobile."&content=".rawurlencode($content);
	

	$get = Post($post_data, $target);
	
	
	write_file($mobile,$get."\r\n".date("Y-m-d H:i:s"));

	if(strpos($get,"success")>-1){
		$_SESSION['mobile']=$mobile;
		$_SESSION['mobile_code']=$mobile_code;	
		exit(json_encode(array('code'=>2)));	
	}else{
		exit(json_encode(array('msg'=>$get.'手机验证码发送失败。')));	
	}
}

function Post($curlPost,$url){
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_HEADER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_NOBODY, true);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $curlPost);
		$return_str = curl_exec($curl);
		curl_close($curl);
		return $return_str;
}

function random($length = 6 , $numeric = 0) {
	PHP_VERSION < '4.2.0' && mt_srand((double)microtime() * 1000000);
	if($numeric) {
		$hash = sprintf('%0'.$length.'d', mt_rand(0, pow(10, $length) - 1));
	} else {
		$hash = '';
		$chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789abcdefghjkmnpqrstuvwxyz';
		$max = strlen($chars) - 1;
		for($i = 0; $i < $length; $i++) {
			$hash .= $chars[mt_rand(0, $max)];
		}
	}
	return $hash;
}
function write_file($file_name,$content){
	mkdirs(date('Ymd'));
	$filename = date('Ymd').'/'.$file_name.'.log';
	$Ts=fopen($filename,"a+");
	fputs($Ts,"\r\n".$content);
	fclose($Ts);
}
function mkdirs($dir, $mode = 0777){
	if (is_dir($dir) || @mkdir($dir, $mode)) return TRUE;
	if (!self::mkdirs(dirname($dir), $mode)) return FALSE;
	return @mkdir($dir, $mode);
}
function read_file($file_name) {
	$content = '';
	$filename = date('Ymd').'/'.$file_name.'.log';
	if(function_exists('file_get_contents')) {
		@$content = file_get_contents($filename);
	} else {
		if(@$fp = fopen($filename, 'r')) {
			@$content = fread($fp, filesize($filename));
			@fclose($fp);
		}
	}
	$content = explode("\r\n",$content);
	return end($content);
}
?>
