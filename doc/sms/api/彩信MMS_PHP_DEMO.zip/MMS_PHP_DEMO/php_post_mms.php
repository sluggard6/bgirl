<?PHP 

//该demo的功能是发彩信
//我们的Demo，都是在UTF-8环境下测试的。如果您的系统是gb2312,请注意转码。
 $file="pic1.gif"; 
  $file2="ww.jpg";
  $file3="ttt.mid";
  $file4="eee.mid";
$fp=fopen($file,"r")or die("Can't open file");  
$PicBase1=base64_encode(fread($fp,filesize($file)));//base64编码 
 $file_content='1_2.gif,'.$PicBase1;//图片第一帧

$fp2=fopen($file2,"r")or die("Can't open file");  
$PicBase2=base64_encode(fread($fp2,filesize($file2)));//base64编码 
 $file_content.=';2_2.jpg,'.$PicBase2;//图片第二帧

 $fp=fopen($file3,"r")or die("Can't open file");  
$audBase1=base64_encode(fread($fp,filesize($file3)));//base64编码 
 $file_content.='1_3.mid,'.$audBase1;//音频第一帧

$fp2=fopen($file4,"r")or die("Can't open file");  
$audBase2=base64_encode(fread($fp2,filesize($file4)));//base64编码 
 $file_content.=';2_3.mid,'.$audBase2;//音频第二帧

$txtBase1=base64_encode("第一条文本：欧耶");//文本第一帧
$txtBase2=base64_encode("第二条文本：哈哈");//文本第二帧
$file_content.=';1_1.txt,'.$txtBase1;
$file_content.=';2_1.txt,'.$txtBase2;//请注意各帧之间用英文的分号隔开
//echo $file_content;
// exit;
$flag = 0; 
        //要post的数据 
$argv = array( 
         'apikey'=>'32eadded3d***', //32位，APIKEY请联系技术人员索取
		 'password'=>'123456', //用户登陆密码
		 'title'=>'test测试彩信',
		 'mobile'=>'13311258675',//手机号 多个号码以半角分号分隔
		 'content'=>$file_content//彩信信内容//base64_encode();
		 ); 
//构造要post的字符串 
foreach ($argv as $key=>$value) { 
          if ($flag!=0) { 
                         $params .= "&"; 
                         $flag = 1; 
          } 
         $params.= $key."="; $params.= urlencode($value); 
         $flag = 1; 
          } 
         $length = strlen($params); 
                 //创建socket连接 
         $fp = fsockopen("m.5c.com.cn",80,$errno,$errstr,10) or exit($errstr."--->".$errno); 
         //构造post请求的头 
         $header = "POST /api/send/caixin_send.php HTTP/1.1\r\n"; 
         $header .= "Host:m.5c.com.cn\r\n"; 
         $header .= "Content-Type: application/x-www-form-urlencoded\r\n"; 
         $header .= "Content-Length: ".$length."\r\n"; 
         $header .= "Connection: Close\r\n\r\n"; 
         //添加post的字符串 
         $header .= $params."\r\n"; 
         //发送post的数据 
         fputs($fp,$header); 
         $inheader = 1; 
          while (!feof($fp)) { 
                         $line = fgets($fp,1024); //去除请求包的头只显示页面的返回数据 
                         if ($inheader && ($line == "\n" || $line == "\r\n")) { 
                                 $inheader = 0; 
                          } 
                          if ($inheader == 0) { 
                                // echo $line; 
                          } 
          }
		  echo $line;
?>
