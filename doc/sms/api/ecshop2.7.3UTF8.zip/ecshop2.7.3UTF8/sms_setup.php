<?php

define('IN_ECS', true);

require(dirname(__FILE__) . '/includes/init.php');

$sql = "SHOW TABLES LIKE '%".$prefix."verify_code%';";
$res = $db->query($sql);
while ($row = $db->fetchRow($res)){
	if($row) {
		exit("已安装！请删除此文件！");
	}
}

$newsql = sreadfile("sms_setup.sql");

if($prefix != 'ecs_') 
	$newsql = str_replace('ecs_', $prefix, $newsql);//替换表名前缀

$sqls = explode(";", $newsql);
foreach ($sqls as $sql) {
	$sql = trim($sql);
	if (empty($sql)) {
		continue;
	}
	if(!$query = $db->query($sql)) {
		exit("执行sql语句出错： ".mysql_error());
	}
}

echo "<h4>美联软通短信插件安装成功，请删除此文件！</h4>";


function sreadfile($filename) {
	$content = '';
	if(function_exists('file_get_contents')) {
		@$content = file_get_contents($filename);
	} else {
		if(@$fp = fopen($filename, 'r')) {
			@$content = fread($fp, filesize($filename));
			@fclose($fp);
		}
	}
	return $content;
}

?>